--This file is not required by the mod.
--This file is a config OVERWRITE, any setting in this file will overwrite the default options of the script.
--You can also modify the defaults in data/scripts/player/DirtyCargoExtender.lua
DirtyCargoExtenderConfig = {}
DirtyCargoExtenderConfig.ModPrefix = "[Dirty Cargo Extender]";
DirtyCargoExtenderConfig.Version = "[1.0.0]";
DirtyCargoExtenderConfig.MaxGoodCount = 10000 --The max quantity of each good per station/mine
return DirtyCargoExtenderConfig
